# Two Sorting Algorithms — All Scenarios

NetBeans/Maven project comparing Merge Sort and Quick Sort on:
1. Random (unsorted)
2. Reverse sorted (largest to smallest)
3. Partially sorted (first 80% ascending; remaining 20% random)
4. Fully sorted (ascending)

Default N = 100000. Results are measured using System.nanoTime(), printed in microseconds, checked for correctness, and saved to benchmark_results.csv.

## Open in NetBeans
1. Extract the ZIP.
2. In NetBeans choose File > Open Project.
3. Select the `TwoAlgorithmsAllScenarios` folder containing `pom.xml`.
4. Run the project.

For a quick test, set program arguments to `10000` in Project Properties > Run > Arguments. Timing depends on your computer; use your actual measured results.
